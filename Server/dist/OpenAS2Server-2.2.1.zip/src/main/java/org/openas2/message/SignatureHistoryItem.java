package org.openas2.message;

public interface SignatureHistoryItem {
    public static final String HIA_SIGNED = "signed";
    public static final String HIA_CERTIFICATE = "certificate";
}
