package org.openas2.lib;

public class Info {
	public static final String NAME = "OpenAS2";
	public static final String VERSION = "v1.0";
	public static final String NAME_VERSION = NAME + " " + VERSION;
}
