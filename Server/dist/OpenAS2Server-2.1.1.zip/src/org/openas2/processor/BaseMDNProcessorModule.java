package org.openas2.processor;

import org.openas2.BaseComponent;


public abstract class BaseMDNProcessorModule extends BaseComponent implements MDNProcessorModule {
   
}
