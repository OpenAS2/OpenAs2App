package org.openas2.partner;


public interface CustomIDPartnership {
    // set this to override the date format used when generating message IDs 
    public static final String PA_DATE_FORMAT = "mid_date_format";
}
