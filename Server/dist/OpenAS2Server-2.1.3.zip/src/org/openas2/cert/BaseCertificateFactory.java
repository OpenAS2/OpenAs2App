package org.openas2.cert;

import org.openas2.BaseComponent;

public abstract class BaseCertificateFactory extends BaseComponent implements CertificateFactory {
	
}