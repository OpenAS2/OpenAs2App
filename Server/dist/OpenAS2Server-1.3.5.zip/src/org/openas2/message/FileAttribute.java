package org.openas2.message;

public interface FileAttribute {     
	public static final String MA_FILEPATH = "filepath";
	public static final String MA_FILENAME = "filename";
	public static final String MA_PENDING = "pending";
	public static final String MA_PENDINGINFO = "pendinginfo";
	public static final String MA_PENDINGFILE = "pendingfilename";
	public static final String MA_STATUS = "status";
}
