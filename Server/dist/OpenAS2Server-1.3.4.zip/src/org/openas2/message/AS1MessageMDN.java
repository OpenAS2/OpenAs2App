package org.openas2.message;

public class AS1MessageMDN extends BaseMessageMDN {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AS1MessageMDN(AS1Message msg) {
        super(msg);
    }

    public String generateMessageID() {
        // TODO Auto-generated method stub
        return null;
    }
}
