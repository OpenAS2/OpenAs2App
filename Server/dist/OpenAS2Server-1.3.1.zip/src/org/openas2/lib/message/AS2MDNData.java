package org.openas2.lib.message;

public class AS2MDNData extends MDNData {
	public AS2MDNData(EDIINTMessageMDN owner) {
		super(owner);
	}

}
