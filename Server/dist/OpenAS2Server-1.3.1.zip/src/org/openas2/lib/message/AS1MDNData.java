package org.openas2.lib.message;


public class AS1MDNData extends MDNData {

	public AS1MDNData(EDIINTMessageMDN owner) {
		super(owner);		
	}

}
