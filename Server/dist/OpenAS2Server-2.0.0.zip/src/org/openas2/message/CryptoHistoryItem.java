package org.openas2.message;

public interface CryptoHistoryItem {
    public static final String HIA_ENCRYPTED = "encrypted";
    public static final String HIA_DECRYPTED = "decrypted";
    public static final String HIA_ALGORITHM = "algorithm";
    public static final String HIA_KEYSIZE = "keysize";
}
