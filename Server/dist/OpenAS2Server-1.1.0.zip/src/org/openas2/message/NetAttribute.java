package org.openas2.message;

public interface NetAttribute {
	public static final String MA_SOURCE_IP = "source_ip";
	public static final String MA_SOURCE_PORT = "source_port";
	public static final String MA_DESTINATION_IP = "destination_ip";
	public static final String MA_DESTINATION_PORT = "destination_port";
}
