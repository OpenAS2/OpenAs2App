package org.openas2.cmd;

public interface CommandRegistryFactory {
	public CommandRegistry getCommandRegistry();
}
