
package org.openas2.partner;


public interface AS1Partnership {
	public static final String PID_AS1 = "as1_id"; // AS1 ID
	
	
}
