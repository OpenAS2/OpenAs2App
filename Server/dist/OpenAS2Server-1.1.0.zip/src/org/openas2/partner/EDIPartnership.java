package org.openas2.partner;


public interface EDIPartnership {
	public static final String PID_EDI = "edi_id"; // EDI ID
}
