package org.openas2.processor.sender;

import org.openas2.processor.BaseProcessorModule;

public abstract class BaseSenderModule extends BaseProcessorModule implements SenderModule {
		
}
