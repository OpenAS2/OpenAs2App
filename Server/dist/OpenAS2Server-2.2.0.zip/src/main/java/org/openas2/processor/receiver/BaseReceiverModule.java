package org.openas2.processor.receiver;

import org.openas2.processor.BaseActiveModule;

public abstract class BaseReceiverModule extends BaseActiveModule implements ReceiverModule {

}
