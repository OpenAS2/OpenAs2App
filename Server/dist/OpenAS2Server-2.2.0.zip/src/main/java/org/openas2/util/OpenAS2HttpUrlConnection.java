package org.openas2.util;

import java.net.HttpURLConnection;
import java.net.URL;

abstract public class OpenAS2HttpUrlConnection extends HttpURLConnection
{

	protected OpenAS2HttpUrlConnection(URL u)
	{
		super(u);
	}

	

}
