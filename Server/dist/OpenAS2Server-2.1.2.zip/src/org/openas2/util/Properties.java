package org.openas2.util;

import java.util.HashMap;
import java.util.Map;

public class Properties
{
	private static Map<String, String> _properties = new HashMap<String, String>();
	
	public static void setProperties(Map<String, String> map)
	{
		_properties = map;
	}

	public static Map<String, String> getProperties()
	{
		return _properties;
	}

	public static String getProperty(String key, String fallback)
	{
		String val = _properties.get(key);
		if (val == null)
		{
			_properties.put(key, fallback);
			return fallback;
		}
		return val;
	}


}
