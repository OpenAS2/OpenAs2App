package org.openas2.processor;

import org.openas2.BaseComponent;


public abstract class BaseProcessorModule extends BaseComponent implements ProcessorModule {
   
}
