
package org.openas2.processor.receiver;

import org.openas2.processor.ActiveModule;


public interface ReceiverModule extends ActiveModule {
	
}
